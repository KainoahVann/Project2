/*
 * File: Blackjack
 * Author: Kainoah Vann
 * Date:
 * Purpose: Project 1 cis-5 Blackjack Game
 * Version:3
 */

 //System Libraries - Post Here
#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here




//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.

//Function Prototypes - Post Here

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here when needed
    srand(time(NULL));
    //Declare variables or constants here
    //7 characters or less

    //variables for decisions

    //const int for spacing loop
    const int out = 50;
    
    // integer variables to count wins and losses
    int wins = 0;
    int losses = 0;
    
    // float variables to keep track of the number of games and plays win rate
    float gameNum = 0;
    float winrt;
    
    // character variables that allow player to play the game, view tutorial, and make choices to hit or stay
    char game_on;
    char tutor;
    char choice;
    
    // strings holding outputs for if player wins or looses
    string win = "You Win!";
    string lose = "You Lose!";
    string final;
    
    // true or false statements showing if player won the round or not
    bool won;
    bool lost;
    
    string winloss;
    
 


    Sleep(1000);
    
    //introduction & Tutorial start

    cout << "Welcome to my Blackjack game!" << endl << endl;
    Sleep(1000);

    cout << "Do you know how to play Blackjack?" << endl << endl;
    Sleep(1000);

    cout << "Type Y if you would like a tutorial, press anything else to continue " << endl;     // asking user input to display tutorial

    cin >> tutor;


    cout << string(50, '\n'); // simple output to space chunks of text



    while (tutor == 'y' || tutor == 'Y') {          // displays if player asks to see the tutorial

        // Output tutorial
        
        Sleep(1000);
        cout << "Here's how you play:" << endl;
        Sleep(1000);

        cout << "The main objective of Blackjack is to beat the dealer." << endl << endl;

        Sleep(1000);
        cout << "You are going to get 2 random cards. You want to make the sum of your cards get as close to the number 21 as possible." << endl << endl;

        Sleep(1000);
        cout << "After seeing your cards, you have a choice to either hit, allowing you to add one more card to your hand, or stay, which keeps your cards as they are." << endl << endl;

        Sleep(1000);
        cout << "You lose if your hand goes over 21, or if the dealers hand is closer to 21 than you." << endl << endl;

        cout << "Do you need to see the rules again?" << endl << endl;

        cin >> tutor;

        for (int j = 1; j < out; ++j) {        //for loop to space the blocks of code by 50 lines

            cout << endl;

        }

    }



                        // starting game
    Sleep(1000);
    cout << endl << endl << "Would you like to play? Type Y if you would like to play " << endl << endl;

    cin >> game_on;
// output to space text by 50 lines
    cout << string(50, '\n');

    while (game_on == 'Y' || game_on == 'y') {

        //card variables (the %10 + 1 is to make sure the random number generated is between 1 and 10 instead of 0 and 10)
        
        int   card4 = rand() % 10 + 1,
            card5 = rand() % 10 + 1,
            card6 = rand() % 10 + 1,
            card7 = rand() % 10 + 1,
            card8 = rand() % 10 + 1,
            card9 = rand() % 10 + 1,
            card10 = rand() % 10 + 1,
            card11 = rand() % 10 + 1,
            card12 = rand() % 10 + 1,
            card13 = rand() % 10 + 1,
            card14 = rand() % 10 + 1,
            card15 = rand() % 10 + 1,
            card16 = rand() % 10 + 1,
            card17 = rand() % 10 + 1,
            card18 = rand() % 10 + 1,
            card19 = rand() % 10 + 1,
            card20 = rand() % 10 + 1,
            card21 = rand() % 10 + 1,
            card22 = rand() % 10 + 1;


        int urhand;

// computer's card variables
        int ccard3 = rand() % 10 + 1,
            ccard4 = rand() % 10 + 1,
            ccard5 = rand() % 10 + 1,
            ccard6 = rand() % 10 + 1,
            ccard7 = rand() % 10 + 1,
            ccard8 = rand() % 10 + 1,
            ccard9 = rand() % 10 + 1,
            ccard10 = rand() % 10 + 1,
            ccard11 = rand() % 10 + 1,
            ccard12 = rand() % 10 + 1,
            ccard13 = rand() % 10 + 1,
            ccard14 = rand() % 10 + 1,
            ccard15 = rand() % 10 + 1,
            ccard16 = rand() % 10 + 1,
            ccard17 = rand() % 10 + 1,
            ccard18 = rand() % 10 + 1,
            ccard19 = rand() % 10 + 1,
            ccard20 = rand() % 10 + 1,
            ccard21 = rand() % 10 + 1,
            ccard22 = rand() % 10 + 1;

        int chand;
// more user card variables
        int     card1 = rand() % 10 + 1,
                card2 = rand() % 10 + 1,
                card3 = rand() % 10 + 1;

        int     ccard1 = rand() % 10 + 1,
                ccard2 = rand() % 10 + 1;

        cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;

        // initial hand & option to hit or stay
        
        cout << "These are your cards" << endl;

        cout << card1 << " " << card2 << endl;
        urhand = card1 + card2;
        chand = ccard1 + ccard2;



        cout << "Would you like to hit (get another card) or stay (keep the cards you currently have)" << endl;
        cout << "Enter H to hit, enter S to stay ";

        cin >> choice;
        
      while(choice != 'h' && choice != 'H' && choice != 's' && choice != 'S' ) {               //validating user input, if not s or h, ask for input again
     cout << "Invalid input. Enter H to hit or S to stay ";
      cin.clear();
      cin.ignore(1000, '\n');
     
      cin >> choice;
    }

        cout << string(50, '\n');
        
        //loop allowing to hit multiple times

        int i = 0;   

        do {         //do while loop that allows user to hit multiple times

            ++i;


            int ncard;


            if (choice == 'h' || choice == 'H') {


                switch (i) {             // each case is another hit that the player is able to do

                case 1:
                    urhand = card1 + card2 + card3;
                    ncard = card3;

                    break;
                case 2:
                    urhand = card1 + card2 + card3 + card4;
                    ncard = card4;

                    break;
                case 3:
                    urhand = card1 + card2 + card3 + card4 + card5;
                    ncard = card5;
                    break;
                case 4:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6;
                    ncard = card6;
                    break;
                case 5:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6 + card7;
                    ncard = card7;
                    break;
                case 6:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6 + card7 + card8;
                    ncard = card8;
                    break;
                case 7:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6 + card7 + card8 + card9;
                    ncard = card9;
                    break;
                case 8:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6 + card7 + card8 + card9 + card10;
                    ncard = card10;
                    break;
                case 9:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6 + card7 + card8 + card9 + card10 + card11;
                    ncard = card11;
                    break;
                case 10:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6 + card7 + card8 + card9 + card10 + card11 + card12;
                    ncard = card12;
                    break;
                case 11:
                    urhand = card1 + card2 + card3 + card4 + card5 + card6 + card7 + card8 + card9 + card10 + card11 + card12 + card13;
                    ncard = card13;
                    break;
                }

                    //output if hit 
                
                cout << endl << "You chose to hit" << endl;
                cout << "You got a new card with the value of " << ncard << endl;

                cout << endl << endl << "Your hand adds up to " << urhand << endl;

            }  // if the user hits, and their hand is under 21, allow them to hit again

            if (urhand < 21 && choice == 'h' || urhand < 21 && choice == 'H') {

                cout << "Do you want to hit again" << endl << "Enter H to hit, enter S to stay ";

                cin >> choice;
                
                 while(choice != 'h' && choice != 'H' && choice != 's' && choice != 'S' ) {            //validating user input, if not s or h, ask for input again
                 cout << "Invalid input. Enter H to hit or S to stay ";
                cin.clear();
                cin.ignore(1000, '\n');
     
      cin >> choice;
    }

                cout << string(50, '\n');
            }
// if the user's hand is above 20, do not allow them to hit
            if (urhand > 20) {
                
                choice = 'a';

            }



        } while (choice == 'H' || choice == 'h');

        //output if stay

        if (choice == 'S' || choice == 's') {

            cout << "You have decided to Stay" << endl << endl;
            cout << "Your hand adds up to " << urhand << endl;

        }

        cout << "The dealers hand adds up to " << chand << endl;

        //win conditions

        if (chand > urhand && chand <= 21) {

            cout << lose << " The dealer's hand was closer to 21 than yours." << endl;     //lose          
            
            won = false;
            lost = true;
                    losses++;
                    
            
        }
        else if (chand > 21 && urhand > 21) {

            cout << "Tie! both hands were greater than 21" << endl;                           //tie
            

        }
        else if (urhand > 21 && chand < 21) {

            cout << lose << " Your hand was above 21" << endl;                                //lose
            
            
            won = false;
            lost = true;
            losses++;
        }
        else if (urhand <= 21 && urhand > chand) {

            cout << win <<" Your hand was closer to 21 than the dealer's hand!" << endl;      // win
            
            
            won = true;
            lost = false;
            wins++;

        }
        else if (chand == urhand) {                                                              //tie
            

            cout << "Tie! neither of you win" << endl;
        }
        
        else if (urhand < 21 && chand > 21) {                                                      //win
            

            cout << win <<" Dealer's hand went above 21" << endl;
        }

     
        
        
    
        
        // inputting wins and losses into a file
        
        fstream scrfile;
        scrfile.open("winloss.txt", ios::out | ios::trunc);
        if(scrfile.is_open()){
            
            scrfile << "Wins: " << wins << endl;
            scrfile << "Losses: " << losses << endl;
     
            
            scrfile.close();
            
            
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        // game loop : play again?
        
        cout << "Would you like to play again?" << endl << endl << "Type Y if you would like to play another round" << endl << endl;
        cin >> game_on;

        cout << string(50, '\n');
    }

  
     
    
    if(game_on != 'Y' || game_on != 'y' && wins > 0 || losses > 0){
        
        
        
        // outputting the wins and losses that were put into the file
        fstream scrfile;
        scrfile.open("winloss.txt", ios::in);
        if (scrfile.is_open()){
            
            string scores;
            while(getline(scrfile, scores)){
                
                
                
                cout << scores << endl;
                
                
            }
            
            scrfile.close();
            
            
        }
        
        
        
        
            
        }
        
        
        
             
    
    
    
    
    // output once the game loop is ended by user
    
     
    if (game_on != 'Y' || game_on != 'y') {

   
     
     
       
        
        
        Sleep(1000);
        // operation to calculate the amount of games played, won, and lost, then conversion into a win ratio
        gameNum = wins + losses;
          winrt = (wins / gameNum) * 100;
          
          gameNum = static_cast<float>(wins+losses);
          
          cout << fixed << setprecision(2);
          cout << "Your win rate was: " << winrt << "%" << endl << endl;
          
             final = (wins > losses) ? "You won more than you lost, good job!" : "You'll win more next time, don't worry!";
             cout << final << endl;
             
         
           Sleep(4000);
        
// exit
           
           
        cout << endl << endl << "Have a nice day!" << endl << endl;
    }


    return 0;
}