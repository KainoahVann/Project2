/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: kainoah Vann
 * Purpose: Project 2 Version 1 
 *
 * Created on May 30, 2022, 5:05 PM
 */

#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;








//Function Prototypes
void Tutorial();
void Welcome();
void Space();
void hit (vector<int>hit);
void chit (vector<int>chit);





 
 
 
 
int main(int argc, char** argv) {
    
    //variables 
 int choice;
 int handttl = 0;
 int cHandt = 0;
 int wins = 0;
 int losses = 0;
 float gamenum = 0;
 float winrt;
 bool won;
 bool lost;
char YN;
char game_on;
string win = "You win! ";
string loss = "You lose! ";
string winloss;
string final;
    
 //setting random seed
    srand(time(NULL));
    
//introduction/Tutorial start
    Welcome();
// simple output to space chunks of text
    Space(); 
// displays tutorial
    
while(YN == 'y' || YN == 'Y'){
    
Tutorial();
    
}

// option to start the game
cout << "Would you like the play? Type Y if you would like to play, Type N if you would not" << endl << endl;

cin >> game_on;

// output to space text by 50 lines
void Space();

// Input Validation
    
    while(game_on != 'y' && game_on != 'Y' && game_on != 'n' && game_on != 'N'){
        
        cout << "Invalid Input. Please type Y to play, or N to not play. " << endl;
        cin >> game_on;
        
    }
       
    
 // GAME START
    
void Space();

    while(game_on == 'Y' || game_on == 'y'){
        
        
        
        int cards[]{1,2,3,4,5,6,7,8,9,10};
        vector<int>pHand;
        vector<int>cHand;
        
        
        pHand.push_back(rand()%10 + 1);
        pHand.push_back(rand()%10 + 1);
        
        cHand.push_back(rand()%10 + 1);
        cHand.push_back(rand()%10 + 1);
        
   for(int i = 0; i < pHand.size(); i++){
            handttl += pHand[i];
        }
        
          for(int i = 0; i < cHand.size(); i++){
            cHandt += cHand[i];
        }
  
      // initial hand & option to hit or stay
        Space();
        cout << "These are your cards" << endl;
      
        for(int i = 0; i < pHand.size(); i++){
            
            cout << pHand[i] << " ";
            
        }
        
        cout << endl;
        
       
        cout << endl << endl;
        
        cout << "Would you like to hit and get another card, or stay with the cards you hold currently?" << endl;
        cout << "Type 1 to hit, or 2 to stay." << endl;
        
        cin >> choice;
        
        
        //input validation
        
      while(choice != 1 && choice != 2) {               //validating user input, if not s or h, ask for input again
     cout << "Invalid input. Enter 1 to hit or 2 to stay ";
      cin.clear();
      cin.ignore(1000, '\n');
     
      cin >> choice;
    }
        
        
        // HITTING ( ADDING NEW CARDS )

        while(choice == 1){
        handttl = 0;
        cHandt = 0;
            
            Space();
         pHand.push_back(rand()%10 + 1);        

            cout << endl;
            cout << "You chose to Hit, and added 1 card to your deck." << endl << endl;
            cout << "Your deck is now" << endl;
            cout << "----------------" << endl;
            
             for(int i = 0; i < pHand.size(); i++){
             cout << pHand[i] << " ";
            
        }
             // CALCULATING PLAYER HAND
         
        for(int i = 0; i < pHand.size(); i++){
            handttl += pHand[i];
        }
            
              cout << endl << "Your hand adds up to: " << handttl << endl;
              
            // CALCULATING DEALER HAND
              
        for(int i = 0; i < cHand.size(); i++){
            cHandt += cHand[i];
        }
            
            /*   if(cHandt < handttl && cHandt < 21){
                   
                   cHand.push_back(rand()%10 + 1);
               }
            */   
               //cout << endl << "Dealer hand adds up to: " << chndttl << endl;
               
// OPTION TO HIT OR STAY
            cout << endl << endl << endl;
            
        cout << "Would you like to hit and get another card, or stay with the cards you hold currently?" << endl;
        cout << "Type 1 to hit, or 2 to stay." << endl;
        
        

       
              
        // checking if bust
        if(handttl > 21){
            choice = 99991;  
        }else{
             cin >> choice;
        }  
        
       }

        
        Space();
        
        cout << "Your hand adds up to " << handttl << endl;
        cout << "Dealer hand adds up to: " << cHandt << endl;
        
        
        
        
        if (choice == 99991){
            
            cout << "You lose! you went above 21" << endl;
             won = false;
            loss = true;
            losses++;
        }
        
        
        
        // Showing hand total if stay
        if (choice == 'S' || choice == 's') {

            handttl = 0;
            cHandt = 0;
            
            for(int i = 0; i < pHand.size(); i++){
            handttl += pHand[i];
        }
            
             for(int i = 0; i < cHand.size(); i++){
            cHandt += cHand[i];
        }
            
            
            cout << "You have decided to Stay" << endl << endl;
            cout << "Your hand adds up to " << handttl << endl;

        }

        
        
        //win/loss conditions
        
        if(cHandt < handttl && handttl <= 21)
        {

            cout << win << "Your hand was closer to 21 than the dealer's hand!" << endl << endl;
            won = true;
            loss = false;
            wins++;
            
        }
        else if(handttl < 21 && cHandt > 21)
        {
            
         cout << win << "Dealer's hand went above 21!" << endl << endl;   
          won = true;
            loss = false;
            wins++;
            
        }
//       else if(handttl > 21 && cHandt < 21)
//       {
//        cout << loss << "Your hand was above 21!" << endl;  
            
//        }
        else if(cHandt < 21 && cHandt > handttl)
        {
          cout << "You lose! Dealer's Hand was closer to 21 than yours!" << endl;  
           won = false;
            loss = true;
            losses++;
        }
        else if(cHandt > 21 && handttl > 21)
        {
            cout << "Tie! Both hands were above 21!" << endl;
        }
        else if(cHandt == handttl)
        {
            cout << "Tie! Both hands were equal!" << endl;
            
        }
        
        
        
        
        
         // inputting wins and losses into a file
        
        fstream scrfile;
        scrfile.open("winloss.txt", ios::out | ios::trunc);
        if(scrfile.is_open()){
            
            scrfile << "Wins: " << wins << endl;
            scrfile << "Losses: " << losses << endl;
     
            
            scrfile.close();
        }
        
        
        
        
        
        
        
        
        // game loop : play again?
        
        handttl = 0;
        cHandt = 0;
        
        pHand.clear();
        cHand.clear();
        
        cout << "Would you like to play again?" << endl << endl << "Type Y if you would like to play another round, Type N if you would not" << endl << endl;
        cin >> game_on;
        
      // Input Validation
    
    while(game_on != 'y' && game_on != 'Y' && game_on != 'n' && game_on != 'N'){
        
        cout << "Invalid Input. Please type Y to play, or N to not play. " << endl;
        cin >> game_on;
    }

        void Space();
        
    }


 if(game_on != 'Y' || game_on != 'y' && wins > 0 || losses > 0){
        
        
        
        // outputting the wins and losses that were put into the file
        fstream scrfile;
        scrfile.open("winloss.txt", ios::in);
        if (scrfile.is_open()){
            
            string scores;
            while(getline(scrfile, scores)){
                
                
                
                cout << scores << endl;
                
                
            }
            
            scrfile.close();
            
            
        }
        
        
        
        
            
        }



 // output once the game loop is ended by user
    
     
    if (game_on != 'Y' || game_on != 'y') {

   
     
     
       
        
        
        Sleep(1000);
        // operation to calculate the amount of games played, won, and lost, then conversion into a win ratio
        gamenum = wins + losses;
          winrt = (wins / gamenum) * 100;
          
          gamenum = static_cast<float>(wins+losses);
          
          cout << fixed << setprecision(2);
          cout << "Your win rate was: " << winrt << "%" << endl << endl;
          
             final = (wins > losses) ? "You won more than you lost, good job!" : "You'll win more next time, don't worry!";
             cout << final << endl;
             
         
           Sleep(4000);
           
    }
        
// exit
        


    



























    return 0;
}



void Tutorial(){
    
    const int space = 50;
    char YN;
    
  // Output tutorial
        
        Sleep(1000);
        cout << "Here's how you play:" << endl;
       // Sleep(1000);

        cout << "The main objective of Blackjack is to beat the dealer." << endl << endl;

       // Sleep(1000);
        cout << "You are going to get 2 random cards. You want to make the sum of your cards get as close to the number 21 as possible." << endl << endl;

      //  Sleep(1000);
        cout << "After seeing your cards, you have a YN to either hit, allowing you to add one more card to your hand, or stay, which keeps your cards as they are." << endl << endl;

       // Sleep(1000);
        cout << "You lose if your hand goes over 21, or if the dealers hand is closer to 21 than you." << endl << endl;

        cout << "Do you understand the rules? Type n to continue, or y if you want the tutorial to be displayed again " << endl << endl;

        cin >> YN;
        
        
     // Input Validation
     while(YN != 'y' && YN != 'Y' && YN != 'n' && YN != 'N' ) {
     cout << "Invalid input. Please enter either Y or N ";
     cin.clear();
     cin.ignore(1000, '\n');
     
      cin >> YN;
   }
        
        
 for (int j = 1; j < space; ++j) {        //for loop to space the blocks of code by 50 lines

            cout << endl;

        }
        
    
}


void Welcome(){
    
    const int space = 50;
    char YN;
    
        cout << "Welcome to my Blackjack game!" << endl << endl;
    // Sleep(1000);

    cout << "Do you know how to play Blackjack?" << endl << endl;
    // Sleep(1000);

    //User input to display YNorial
    cout << "Type y if you would like to see the tutorial, type n to continue" << endl;
    
      //type y or n 
    cin >> YN;
    
    
    // Input Validation
     while(YN != 'y' && YN != 'Y' && YN != 'n' && YN != 'N' ) {
     cout << "Invalid input. Please enter either Y or N ";
     cin.clear();
     cin.ignore(1000, '\n');
     
      cin >> YN;
   }
    
}



void Space(){
    
    
    cout << string(50, '\n');
}


