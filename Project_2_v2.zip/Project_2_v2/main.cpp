/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: kainoah Vann
 * Purpose: Project 2 Version 1 
 *
 * Created on May 30, 2022, 5:05 PM
 */

#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;








//Function Prototypes
void Tutorial();
void Welcome();
void Space();
void IntHand (vector<int>& hit);
void chit (vector<int>chit);
void counter();
void end(int a);
void end(float a);
void opt(string a = "Have a nice day");

void bsort(int arr[], int n);
void ssort(int arr[], int n);
void parray(int arr[], int size);

bool morewin(int, int);


int gameP(int, int);
int search(int arr[],int n, int x);
 
 
 //main
int main(int argc, char** argv) {
    
    //variables 
 int choice;
 int handttl = 0;
 int cHandt = 0;
 int wins = 0;
 int losses = 0;
 int winrtN;
 int gamesP;
 int count;
 int scr[10];
 int selec;
 int num;
 
 string name[3];
 int score1[3];
 int score2[3];
 
 float avg[3];
 
 float gamenum = 0;
 float winrt;
 bool won;
 bool lost;
char YN;
char game_on;
string win = "You win! ";
string loss = "You lose! ";
string winloss;
string final;
string bye = "Goodbye";
const int space = 50;



    
 //setting random seed
    srand(time(NULL));
    
//introduction/Tutorial start
   cout << "Welcome to my Blackjack game!" << endl << endl;
    // Sleep(1000);

    cout << "Do you know how to play Blackjack?" << endl << endl;
    // Sleep(1000);

    //User input to display YNorial
    cout << "Type y if you would like to see the tutorial, type n to continue" << endl;
    
      //type y or n 
    cin >> YN;
    
    
    // Input Validation
     while(YN != 'y' && YN != 'Y' && YN != 'n' && YN != 'N' ) {
     cout << "Invalid input. Please enter either Y or N ";
     cin.clear();
     cin.ignore(1000, '\n');
     
      cin >> YN;
   }
// simple output to space chunks of text
    Space(); 
// displays tutorial
    
while(YN == 'y' || YN == 'Y'){
    
// Output tutorial
        
        Sleep(1000);
        cout << "Here's how you play:" << endl;
       // Sleep(1000);

        cout << "The main objective of Blackjack is to beat the dealer." << endl << endl;

       // Sleep(1000);
        cout << "You are going to get 2 random cards. You want to make the sum of your cards get as close to the number 21 as possible." << endl << endl;

      //  Sleep(1000);
        cout << "After seeing your cards, you have a choice to either hit, allowing you to add one more card to your hand, or stay, which keeps your cards as they are." << endl << endl;

       // Sleep(1000);
        cout << "You lose if your hand goes over 21, or if the dealers hand is closer to 21 than you." << endl << endl;

        cout << "Do you understand the rules? Type n to continue, or y if you want the tutorial to be displayed again " << endl << endl;

        cin >> YN;
        
        
     // Input Validation
     while(YN != 'y' && YN != 'Y' && YN != 'n' && YN != 'N' ) {
     cout << "Invalid input. Please enter either Y or N ";
     cin.clear();
     cin.ignore(1000, '\n');
     
      cin >> YN;
   }
        
        
 for (int j = 1; j < space; ++j) {        //for loop to space the blocks of code by 50 lines

            cout << endl;

        }
        
    
}

// option to start the game
cout << "Would you like the play? Type Y if you would like to play, Type N if you would not" << endl << endl;

cin >> game_on;

// output to space text by 50 lines
void Space();

// Input Validation
    
    while(game_on != 'y' && game_on != 'Y' && game_on != 'n' && game_on != 'N'){
        
        cout << "Invalid Input. Please type Y to play, or N to not play. " << endl;
        cin >> game_on;
        
    }

if (game_on == 'n' || game_on == 'N'){
    
    exit(0);
}
       
    
 // GAME START
    
void Space();

    while (game_on == 'Y' || game_on == 'y'){
 
        // setting initial hand for player and dealer
        int cards[]{1,2,3,4,5,6,7,8,9,10};
        vector<int>pHand;
        vector<int>cHand;
        
        
       // pHand.push_back(rand()%10 + 1);
        //pHand.push_back(rand()%10 + 1);
        
        IntHand(pHand);
        
        cHand.push_back(rand()%10 + 1);
        cHand.push_back(rand()%10 + 1);
        
   for(int i = 0; i < pHand.size(); i++){
            handttl += pHand[i];
        }
        
          for(int i = 0; i < cHand.size(); i++){
            cHandt += cHand[i];
        }
  
      // initial hand & option to hit or stay
        Space();
        cout << "These are your cards" << endl;
      
        for(int i = 0; i < pHand.size(); i++){
            
            cout << pHand[i] << " ";
            
        }
        
        cout << endl;
        
       
        cout << endl << endl;
        
        cout << "Would you like to hit and get another card, or stay with the cards you hold currently?" << endl;
        cout << "Type 1 to hit, or 2 to stay." << endl;
        
        cin >> choice;
        
        
        //input validation
        
      while(choice != 1 && choice != 2) {               //validating user input, if not s or h, ask for input again
     cout << "Invalid input. Enter 1 to hit or 2 to stay ";
      cin.clear();
      cin.ignore(1000, '\n');
     
      cin >> choice;
    }
        
        
        // HITTING ( ADDING NEW CARDS )

        while(choice == 1){
        handttl = 0;
        cHandt = 0;
            
            Space();
         pHand.push_back(rand()%10 + 1);        

            cout << endl;
            cout << "You chose to Hit, and added 1 card to your deck." << endl << endl;
            cout << "Your deck is now" << endl;
            cout << "----------------" << endl;
            
             for(int i = 0; i < pHand.size(); i++){
             cout << pHand[i] << " ";
            
        }
             // CALCULATING PLAYER HAND
         
        for(int i = 0; i < pHand.size(); i++){
            handttl += pHand[i];
        }
            
              cout << endl << "Your hand adds up to: " << handttl << endl;
              
            // CALCULATING DEALER HAND
              
        for(int i = 0; i < cHand.size(); i++){
            cHandt += cHand[i];
        }
            
            /*   if(cHandt < handttl && cHandt < 21){
                   
                   cHand.push_back(rand()%10 + 1);
               }
            */   
               //cout << endl << "Dealer hand adds up to: " << chndttl << endl;
               
// OPTION TO HIT OR STAY
            cout << endl << endl << endl;
            
        cout << "Would you like to hit and get another card, or stay with the cards you hold currently?" << endl;
        cout << "Type 1 to hit, or 2 to stay." << endl;
        
        

       
              
        // checking if bust
        if(handttl > 21){
            choice = 99991;  
        }else{
             cin >> choice;
        }  
        
       }

        
        Space();
        
        cout << "Your hand adds up to " << handttl << endl;
        cout << "Dealer hand adds up to: " << cHandt << endl;
        
        
        
        
        if (choice == 99991){
            
            cout << "You lose! you went above 21" << endl;
             won = false;
            loss = true;
            losses++;
        }
        
        
        
        // Showing hand total if stay
        if (choice == 'S' || choice == 's') {

            handttl = 0;
            cHandt = 0;
            
            for(int i = 0; i < pHand.size(); i++){
            handttl += pHand[i];
        }
            
             for(int i = 0; i < cHand.size(); i++){
            cHandt += cHand[i];
        }
            
            
            cout << "You have decided to Stay" << endl << endl;
            cout << "Your hand adds up to " << handttl << endl;

        }

        
        
        //win/loss conditions
        
        if(cHandt < handttl && handttl <= 21)
        {

            cout << win << "Your hand was closer to 21 than the dealer's hand!" << endl << endl;
            won = true;
            loss = false;
            wins++;
            
        }
        else if(handttl < 21 && cHandt > 21)
        {
            
         cout << win << "Dealer's hand went above 21!" << endl << endl;   
          won = true;
            loss = false;
            wins++;
            
        }
//       else if(handttl > 21 && cHandt < 21)
//       {
//        cout << loss << "Your hand was above 21!" << endl;  
            
//        }
        else if(cHandt < 21 && cHandt > handttl)
        {
          cout << "You lose! Dealer's Hand was closer to 21 than yours!" << endl;  
           won = false;
            loss = true;
            losses++;
        }
        else if(cHandt > 21 && handttl > 21)
        {
            cout << "Tie! Both hands were above 21!" << endl;
        }
        else if(cHandt == handttl)
        {
            cout << "Tie! Both hands were equal!" << endl;
            
        }
        
        
        
        
        
         // inputting wins and losses into a file
        
        fstream scrfile;
        scrfile.open("winloss.txt", ios::out | ios::trunc);
        if(scrfile.is_open()){
            
            scrfile << "Wins: " << wins << endl;
            scrfile << "Losses: " << losses << endl;
     
            
            scrfile.close();
        }
        
        
        
        
        
        
        
        
        // game loop : play again?
        
        handttl = 0;
        cHandt = 0;
        
        pHand.clear();
        cHand.clear();
        
        cout << endl << endl << "You have replayed this game: ";
        counter();
        cout << " times" << endl;
        
        cout << "Would you like to play again?" << endl << endl << "Type Y if you would like to play another round, Type N if you would not" << endl << endl;
        cin >> game_on;
        
        
        
      // Input Validation
    
    while(game_on != 'y' && game_on != 'Y' && game_on != 'n' && game_on != 'N'){
        
        cout << "Invalid Input. Please type Y to play, or N to not play. " << endl;
        cin >> game_on;
    }

        void Space();
        
    }


 if(game_on != 'Y' || game_on != 'y' && wins > 0 || losses > 0){
        
        Space();
        
        // outputting the wins and losses that were put into the file
        fstream scrfile;
        scrfile.open("winloss.txt", ios::in);
        if (scrfile.is_open()){
            
            string scores;
            while(getline(scrfile, scores)){
                
                
                
                cout << scores << endl;
                
                
            }
            
            scrfile.close();
            
            
        }
        
        
        
        
            
        }



 // output once the game loop is ended by user
    
     
    if (game_on != 'Y' || game_on != 'y') {

        Sleep(1000);
        // operation to calculate the amount of games played, won, and lost, then conversion into a win ratio
        gamenum = wins + losses;
        
          winrt = (wins / gamenum) * 100;
          winrtN = (wins / gamenum) * 100;
          
          gamenum = static_cast<float>(wins+losses);
          
           cout << "You played ";
           cout << gameP(wins, losses);
           cout << " Times" << endl;
           
          
         // cout << "Your win rate was: " << winrt << "%" << endl << endl;
          end(winrtN);
          end(winrt);
          
          
          if (morewin(wins, losses))
              cout << endl << "You are a Winner! ";
          else
              cout << endl << "You are a Loser! ";
         
          
             final = (wins > losses) ? "You won more than you lost, good job!" : "You'll win more next time, don't worry!";
             cout << final << endl;
             
             
             Sleep(10000);
             Space();
             
     
                 
             }
             
             // entering different section of game
            cout << "Type 1 if you would like to enter the score sorting section, type anything else if not" << endl;
             cin >> selec;
             
             if(selec == 1){
                 
                 //10 scores to be put in array
                 cout << "Enter 10 scores" << endl << endl << endl;
                 
                 for (count = 0; count < 10; count++){
                     
                     cout << "Number " << (count + 1) << ":" << endl;
                     cin >> scr[count];
                     Space();
                 }
                 
                 
                 cout << endl << "You input: " << endl;
                 
                 for(int i=0;i<10;i++)
                 cout<<scr[i]<<" ";
                 cout<<endl;
                 
                 Space();
                 cout << "You have 6 options to choose from: " << endl;
                 cout << "Enter 1 for bubble sort, 2 for selection sort, 3 to search for a value, 4 to see parallel arrays,"
                                 "5 to see 2d arrays, and anything else to leave" << endl << endl;
                 cin >> selec;
                 
                 //bubble sort
                 while (selec == 1) {
                     Space();
                 bsort(scr, 10);

                 cout << "This array bubble sorted is: " << endl << endl;
                 
                 parray(scr,10);
                 
                 cout << endl;
                 
                 cout << "Enter 1 for bubble sort, 2 for selection sort, 3 to search for a value, 4 to see parallel arrays,"
                                 "5 to see 2d arrays, and anything else to leave" << endl;
                         
                 cin >> selec;
                 }
                 
                 
                 //selection sort
                 while (selec == 2){
                     Space();
                     
                     ssort(scr, 10);
                     cout << "This array selection sorted is: " << endl << endl;
                     parray(scr,10);
                     
                     cout << endl;
                     
                             
                cout << "Enter 2 for selection sort, 3 to search for a value, 4 to see parallel arrays,"
                                 "5 to see 2d arrays, and anything else to leave" << endl;
                 cin >> selec;
                 }
                 
                 
                 // linear search
                 while (selec == 3){
                     Space();
               
                     cout << "What number would you like to look for?" << endl << endl;
                     cin >> num;
                     cout << endl;
                     int result = search(scr, 10, num);
                     
                     (result == -1) ? cout << "Element is not present in array" << endl : cout << "Element is present at index " << result << endl;
                      
                         
                 cout << endl << "Enter 3 to search for a value, 4 to see parallel arrays,"
                                 "5 to see 2d arrays, and anything else to leave" << endl;
                 cin >> selec;
                 }
                 //parallel arrays
                 while (selec == 4){
                     
                     Space();
                     
                     cout << "Parallel arrays" << endl;
                     
                     for(int i = 0; i <= 2; i++){
                         
                         cout << "Enter Name: ";
                         cin >> name[i];
                         
                         cout << endl << "Enter your score: ";
                         cin >> score1[i];
                         
                          cout << endl << "Enter second score: ";
                         cin >> score2[i];
                     }
                     
                     for (int i=0;i<2;i++){
                         
                         avg[i] = (score1[i] + score2[i]) / 2;
                     }
                     
                     cout << endl;
                     
                     cout << "Name" << "          " << "Average score" << endl;
                     
                     for (int i = 0; i <=2; i++){
                         
                         cout << fixed << setprecision(2);
                         
                         cout << name[i] << "          " << avg[i] << endl;
                     }
                     
                     
                     
                      cout << endl << "Enter 4 to see parallel arrays,"
                      "5 to see 2d arrays, and anything else to leave" << endl;
                       cin >> selec;
                 }
                 // 2d arrays
                 while (selec == 5){
                     
                     Space();
                     
                     cout << "2d arrays" << endl;
                     
                     int array2d[4][10]= {
                                            {1,2,3,4,5,6,7,8,9,10},
                                            {1,2,3,4,5,6,7,8,9,10},
                                            {1,2,3,4,5,6,7,8,9,10},
                                            {1,2,3,4,5,6,7,8,9,10}
                                          };
                     
                       for (int row = 0; row < 4;row++) {
                         for (int column = 0; column < 10;column++) {
                             cout << array2d[row][column] << " ";

        }

        cout << endl;

    }

                     
                     
                      cout << endl << "Enter 5 to see 2d arrays, and anything else to leave" << endl;
                 cin >> selec;
                 }
                 
                 
                 
                 
                          
                 if(selec != 1 || selec != 2 || selec != 3 || selec != 4 || selec != 5){
                     
                     cout << "Okay, maybe next time" << endl;
                 }
             
             
             
             
             
             
             
             
             
             
             
             
           Sleep(8000);
        
           Space();
           
          //overloaded function to display goodbye message
            opt(bye);
            opt();
             
             Sleep(8000);

           
           
           
           
           
           
           
           
    }
        
// exit
        


    



























    return 0;
}


void Space(){
    
    
    cout << string(50, '\n');
}


void IntHand (vector<int>& hit){
    
        hit.push_back(rand()%10 + 1);
        hit.push_back(rand()%10 + 1);
    
}


bool morewin(int w, int l){
    
    if (w > l)
        return true;
    else
        return false;
    
    
}

void counter(){
    
    static int count = 0;
    cout << count++;
}


void end(int a){
    cout << fixed << setprecision(2);
    cout << "Your win rate rounded was " << a << "%" << endl;
    
}

void end (float a){
    
    cout << "Your exact win rate was " << a << "%" << endl;
}


void opt(string a){
    
    cout << a << endl;
}


int gameP(int x, int y){
    
    return x + y;
}


void bsort(int arr[], int n){
    
    
    int i, j;
    for (i = 0; i < n - 1; i++)
 
    for (j = 0; j < n - i - 1; j++)
    if (arr[j] > arr[j + 1])
    swap(arr[j], arr[j + 1]);
    
    
}
void parray(int arr[], int size){
    
    int i;
    for (i = 0; i < size; i++)
    cout << arr[i] << " ";
    cout << endl;
    
}


void ssort(int arr[], int n){
    
    
     int i, j, min;
     
   for (i = 0; i < n-1; i++)
    {
       
       
        min = i;
        for (j = i+1; j < n; j++)
        if (arr[j] < arr[min])
            min = j;
 
        // Swap the found minimum element
        // with the first element
        swap(arr[min], arr[i]);
    }
}


int search(int arr[],int n, int x){
    
    
    int i;
    for (i = 0; i < n; i++)
        if (arr[i] == x)
            return i;
    return -1;
    
    
}
    
    
    
